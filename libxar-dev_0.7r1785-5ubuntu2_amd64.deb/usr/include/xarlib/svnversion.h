const TCHAR g_pszSvnVersion[] = wxT("");
const TCHAR g_pszAppVersion[] = wxT("0.7");
#define CAMELOT_VERSION_MAJOR 
#define CAMELOT_VERSION_MINOR 
#define CAMELOT_VERSION 0.7
#define CAMELOT_VERSION_STRING wxT("0.7 (buildd)")
#define CAMELOT_BUILD_DATE _T("14-Apr-13 01:27")
